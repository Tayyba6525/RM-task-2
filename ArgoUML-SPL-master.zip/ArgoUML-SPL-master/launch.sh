mvn clean package
java -jar ./src/argouml-build/target/argouml-jar-with-dependencies.jar